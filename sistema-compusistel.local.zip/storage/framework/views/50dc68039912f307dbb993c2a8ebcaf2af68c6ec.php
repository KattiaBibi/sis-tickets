<!doctype html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
  <title>Asignación al requerimiento: <?php echo e(strtoupper($requerimiento->titulo)); ?></title>
</head>

<body>

  <?php
  $encargados = "";
  foreach ($requerimiento->encargados as $encargado) {
    $encargados .= $encargado->nom_ape_encargado . ', ';
  }

  $asignados = "";
  foreach ($requerimiento->asignados as $asignado) {
    $asignados .= $asignado->nom_ape_asignado . ', ';
  }
  ?>

  <p>👉 Hola!, <?php echo e(strtoupper($colaborador->nombre)); ?> <?php echo e(strtoupper($colaborador->apellido)); ?>, tienes un requerimiento pendiente. <br>

    <strong>✅ TITULO: </strong> <?php echo e(strtoupper($requerimiento->titulo)); ?> <br>
    <strong>✅ SOLICITANTE: </strong> <?php echo e($requerimiento->nom_ape_solicitante); ?> <br>
    <strong>✅ EMPRESA SOLICITANTE: </strong> <?php echo e(strtoupper($requerimiento->nombre_empresa)); ?> <br>
    <strong>✅ PRIORIDAD: </strong> <?php echo e(strtoupper($requerimiento->prioridad)); ?> <br>
    <strong>✅ SERVICIO: </strong> <?php echo e(strtoupper($requerimiento->nombre_servicio)); ?> <br>
    <strong>✅ FECHA CREACION: </strong> <?php echo e($requerimiento->fecha_creacion); ?> <br>
    <strong>✅ ENCARGADO(S): </strong> <?php echo e(!empty($encargados) ? $encargados : '---'); ?> <br>
    <strong>✅ ASIGNADO(S): </strong> <?php echo e(!empty($asignados) ? $asignados : '---'); ?> <br>

  </p>

</body>

</html><?php /**PATH C:\wamp64\www\sistema-compusistel.local\resources\views/mails/requerimiento.blade.php ENDPATH**/ ?>