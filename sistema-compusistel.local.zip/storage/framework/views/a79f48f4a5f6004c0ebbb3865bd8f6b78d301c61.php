<div class="card">
  <div class="card-header">
    <div class="row">
      <div class="col-lg-10">
        <h2>Listar</h2>
      </div>
      <div class="col-lg-2">
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalServicio">AGREGAR</button>
      </div>
    </div>
  </div>
  <div class="card-body">
    <table id="tablaEmpresaServicio" class="table table-striped table-bordered">
      <thead>
        <tr>
          <th></th>
          <th>ID</th>
          <th>EMPRESA</th>
        </tr>
      </thead>
      <tbody>
      </tbody>
    </table>
  </div>
</div><?php /**PATH C:\wamp64\www\sistema-compusistel.local\resources\views/empresa_servicio/tables/index.blade.php ENDPATH**/ ?>