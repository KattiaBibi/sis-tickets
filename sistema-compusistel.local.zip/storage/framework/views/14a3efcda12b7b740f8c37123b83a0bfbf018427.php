<!doctype html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
  <?php if($tipoAsunto === 'INVITACION'): ?>
    <title>Invitación a la reunión <?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->titulo); ?></title>
  <?php elseif($tipoAsunto === 'REPROGRAMACION'): ?>
    <title>Reprogramación de la reunión <?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->titulo); ?></title>
  <?php else: ?>
    <title>Se te eliminó de la reunión <?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->titulo); ?></title>
  <?php endif; ?>
</head>

<body>

  <?php if($tipoAsunto === 'INVITACION'): ?>
    <p>Hola!, <?php echo e($asistente->nombres); ?> <?php echo e($asistente->apellidos); ?>, el anfitrion de la reunión
      <strong><?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->registrado_por); ?></strong>, te agendo en la
      reunión:
      <strong><?php echo e($cita->titulo); ?></strong> que se llevara a cabo la fecha:
      <strong><?php echo e(date('d/m/Y', strtotime($cita->fecha))); ?></strong> desde las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_inicio))); ?></strong> hasta las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_fin))); ?></strong> y solicitamos confirmes tu asistencia:
    </p>
    <p>
      <span>¿Confirmas tu asistencia?</span>
      <br>
      <a href="<?php echo e(url('/')); ?>/cita/confirmar-asistencia?respuesta=SI&detalle_cita_id=<?php echo e($asistente->detalle_cita_id); ?>&hash=<?php echo e(password_hash($asistente->detalle_cita_id, PASSWORD_DEFAULT)); ?>" target="_blank">SI</a>
      <br>
      <a href="<?php echo e(url('/')); ?>/cita/confirmar-asistencia?respuesta=NO&detalle_cita_id=<?php echo e($asistente->detalle_cita_id); ?>&hash=<?php echo e(password_hash($asistente->detalle_cita_id, PASSWORD_DEFAULT)); ?>" target="_blank">NO</a>
    </p>
  <?php elseif($tipoAsunto === 'REPROGRAMACION'): ?>
    <p>Hola!, <?php echo e($asistente->nombres); ?> <?php echo e($asistente->apellidos); ?>, el anfitrion de la reunión
      <strong><?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->registrado_por); ?></strong>, reprogramo la
      reunión:
      <strong><?php echo e($cita->titulo); ?></strong> que se llevara a cabo la fecha:
      <strong><?php echo e(date('d/m/Y', strtotime($cita->fecha))); ?></strong> desde las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_inicio))); ?></strong> hasta las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_fin))); ?></strong> y solicitamos confirmes tu asistencia:
    </p>
    <p>
      <span>¿Confirmas tu asistencia?</span>
      <br>
      <a href="<?php echo e(url('/')); ?>/cita/confirmar-asistencia?respuesta=SI&detalle_cita_id=<?php echo e($asistente->detalle_cita_id); ?>&hash=<?php echo e(password_hash($asistente->detalle_cita_id, PASSWORD_DEFAULT)); ?>" target="_blank">SI</a>
      <br>
      <a href="<?php echo e(url('/')); ?>/cita/confirmar-asistencia?respuesta=NO&detalle_cita_id=<?php echo e($asistente->detalle_cita_id); ?>&hash=<?php echo e(password_hash($asistente->detalle_cita_id, PASSWORD_DEFAULT)); ?>" target="_blank">NO</a>
    </p>
  <?php else: ?>
    <p>Hola!, <?php echo e($asistente->nombres); ?> <?php echo e($asistente->apellidos); ?>, el anfitrion de la reunion
      <strong><?php echo e(strtoupper($cita->tipo)); ?> <?php echo e($cita->registrado_por); ?></strong>, te eliminó de la
      reunion:
      <strong><?php echo e($cita->titulo); ?></strong> que se llevara a cabo la fecha:
      <strong><?php echo e(date('d/m/Y', strtotime($cita->fecha))); ?></strong> desde las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_inicio))); ?></strong> hasta las
      <strong><?php echo e(date('h:i A', strtotime($cita->fecha_fin))); ?></strong>
    </p>
  <?php endif; ?>


</body>

</html><?php /**PATH C:\wamp64\www\sistema-compusistel.local\resources\views/mails/cita.blade.php ENDPATH**/ ?>