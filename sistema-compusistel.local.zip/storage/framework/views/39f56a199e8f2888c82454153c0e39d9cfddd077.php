
<?php $__env->startSection('content_header'); ?>
<h1>Empresas y Servicios</h1>
<?php $__env->startSection('title', 'Empresas y Servicios'); ?>
<?php $__env->stopSection(); ?>
<style>
  td.details-control {
    background: transparent url('https://datatables.net/examples/resources/details_open.png') no-repeat center center;
    cursor: pointer;
  }

  tr.shown td.details-control {
    background: transparent url('https://datatables.net/examples/resources/details_close.png') no-repeat center center;
  }

  .test {
    width: 8% !important;
  }
</style>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('empresa_servicio.tables.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('empresa_servicio.forms.servicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('js/empresa_servicio.js')); ?>"></script>
<script>
  listar()
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sistema-compusistel.local\resources\views/empresa_servicio/index.blade.php ENDPATH**/ ?>