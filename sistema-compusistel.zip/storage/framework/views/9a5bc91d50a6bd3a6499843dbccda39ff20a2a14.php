

<?php $__env->startSection('content_header'); ?>
    <h1>Estados</h1>
    <?php $__env->startSection('title', 'Estados'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">  
      
  <div class="card-header">

  <div class="row">
        <div class="col-lg-10">
                <h2>Listar</h2>
        </div>
        <div class="col-lg-2">

        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModalCenter">AGREGAR</button>
    
        </div>
    </div>
    </div>

  <div class="card-body">

  <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" id="mensaje">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
 

    <table id="estados" class="table table-striped table-bordered" style="">
        <thead>
            <tr>
                <th>ID</th>
                <th>NOMBRE</th>

               <th width="280px" class="text-center">ACCIÓN</th>
          
            </tr>
        </thead>
       <tbody>
   

        </tbody> 
        <tfoot>
            <tr>
            <th>ID</th>
            <th>NOMBRE</th>
           <th width="280px" class="text-center">ACCIÓN</th>
              
            </tr>
        </tfoot>
    </table>

  </div>
</div>


<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Nuevo registro</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>¡Ups!</strong> Hubo algunos problemas con tus inputs.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('estado.store')); ?>" id="frmguardar" >
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Nombre:</label>
            <input type="text" class="form-control" id="txtNombre" placeholder="Ingrese el nombre" name="nombre">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
        <button  id="btnguardar" class="btn btn-primary">GUARDAR</button>
      </div>
    </form>
    
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

<script> console.log('¡HOLA!'); </script>

<script src="<?php echo e(asset('js/estado.js')); ?>"></script>



<script>

listar()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis-tickets\resources\views/estado/index.blade.php ENDPATH**/ ?>