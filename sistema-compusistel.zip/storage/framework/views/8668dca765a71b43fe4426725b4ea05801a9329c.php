
<?php $__env->startSection('content_header'); ?>
    <h1>Usuarios</h1>
    <?php $__env->startSection('title', 'Usuarios'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">

  <div class="card-header">

  <div class="row">
        <div class="col-lg-10">
                <h2>Listar</h2>
        </div>
        <div class="col-lg-2">

        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modalagregar">AGREGAR</button>

        </div>
    </div>
    </div>

  <div class="card-body">

  <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" id="mensaje">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>


    <table id="usuarios" class="table table-striped table-bordered" style="">
        <thead>
            <tr>
                <th></th>
                <th>NOMBRE</th>
                <th>EMAIL</th>
                
                <th  style="text-align: center;">ACCIÓN</th>

            </tr>
        </thead>
       <tbody>


        </tbody>
        <tfoot>
            <tr>
                <th></th>
                <th>NOMBRE</th>
                <th>EMAIL</th>
                

                <th >ACCIÓN</th>

            </tr>
        </tfoot>
    </table>

  </div>
</div>


<div class="modal fade" id="modalagregar" tabindex="-1" role="dialog" aria-labelledby="modalagregar" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Nuevo registro</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>¡Ups!</strong> Hubo algunos problemas con tus inputs.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('usuario.store')); ?>" id="frmguardar" >

        <div class="form-group">
            <label for="">Nombre:</label>
            <input type="text" class="form-control" id="txtNombre" placeholder="Ingrese el nombre" name="name">
        </div>
        <div class="form-group">
            <label for="">Email:</label>
            <input type="email" class="form-control" id="txtEmail" placeholder="Ingrese la dirección" name="email">
        </div>

        <div class="form-group">
            <label for="">Contraseña:</label>
            <input type="password" class="form-control" id="txtPassword" placeholder="Ingrese una contraseña" name="password">
        </div>

        <div class="form-group">
            <label for="">Colaborador:</label>

            <select name="colaborador_id" id="txtColaboradorId" class="form-control">
              <option value="a">Elegir</option>

              <?php $__currentLoopData = $colaboradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>"><?php echo e($c->nombres); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
        <button  id="btnguardar" class="btn btn-primary">GUARDAR</button>
      </div>
    </form>

    </div>
  </div>
</div>



<div class="modal fade" id="modaleditar" tabindex="-1" role="dialog" aria-labelledby="modaleditar" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Actualiza registro</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
              <strong>¡Ups!</strong> Hubo algunos problemas con tus inputs.<br><br>
              <ul>
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
          </div>
      <?php endif; ?>
      <form  id="frmeditar">

          <div class="form-group">
              <label for="">Nombre:</label>
              <input type="hidden" class="form-control" id="idregistro"  name="id">

              <input type="text" class="form-control" id="editarNombre" placeholder="Ingrese el nombre" name="name">
          </div>
          <div class="form-group">
              <label for="">Email:</label>
              <input type="text" class="form-control" id="editarEmail" placeholder="Ingrese la dirección" name="email">
          </div>

          <div class="form-group">
            <label for="">Contraseña:</label>
            <input type="text" class="form-control" id="editarContrasena" placeholder="Ingrese la dirección" name="password">
        </div>

        <div class="form-group">
            <label for="">Colaborador:</label>

            <select name="colaborador_id" id="editarColaborador" class="form-control">
              <option value="a">Elegir</option>

              <?php $__currentLoopData = $colaboradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>"><?php echo e($c->nombres); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>


        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
          <button type="submit" id="btnactualizar" class="btn btn-primary">EDITAR</button>
        </div>
      </form>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

<script> console.log('¡HOLA!');

</script>
<script src="<?php echo e(asset('js/usuario.js')); ?>"></script>



<script>

listar();
decrypt();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis-tickets\resources\views/usuario/index.blade.php ENDPATH**/ ?>