<?php $__env->startSection('content_header'); ?>
    <h1>Requerimientos</h1>
    <?php $__env->startSection('title', 'Requerimientos'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<style>

.select2-container--default .select2-selection--multiple .select2-selection__choice{

    color: rgb(172, 30, 30) !important;

}
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">

  <div class="card-header">

  <div class="row">
        <div class="col-lg-2">
                <h4>Buscar por:</h4>
        </div>


    <div class="col-lg-2">

            <select class="form-control" id="filtros">
                <option value="todos" selected>Todos los estados ...</option>
                <option value="pendiente">PENDIENTE</option>
                <option value="en espera">EN ESPERA</option>
                <option value="en proceso">EN PROCESO</option>
                <option value="culminado">CULMINADO</option>
                <option value="cancelado">CANCELADO</option>
              </select>
    </div>


    <div class="col-lg-2">

        <select class="form-control" id="filtrosempre">
            <option value="todos" selected>Todas las empresas ...</option>

            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($e->nombre); ?>"><?php echo e($e->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </select>
    </div>

    <div class="col-lg-2">


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.requerimientos.listartipopersonal')): ?>


        <select class="form-control" id="filtronb">
            <option value="todos" selected>Todo  ...</option>
            <option value="solicitante">Solicitante</option>
            <option value="encargado">Encargado</option>
            <option value="asignado">Asignado</option>

          </select>

        <?php endif; ?>


    </div>

    <div class="col-lg-2" style="text-align: center;">

        

        <button type="button" class="btn btn-info" id="btnquitarfiltros">BORRAR FILTROS</button>

        


    </div>

        <div class="col-lg-2" style="text-align: right;">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin.requerimientos.agregar')): ?>

            <button type="button" class="btn btn-success" id="btnagregar" data-toggle="modal" data-target="#modalagregar">AGREGAR</button>

            <?php endif; ?>



        </div>
    </div>

    </div>

  <div class="card-body">

  <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success" id="mensaje">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table id="requerimientos" class="table table-striped table-bordered" style="overflow-x:auto;">
        <thead>
            <tr>
                <th colspan="3">OPCIONES</th>
                <th>ID</th>
                <th>TITULO</th>
                <th>SOLICITANTE</th>
                <th>ENCARGADO(S)</th>
                <th>ASIGNADO(S)</th>
                <th>EMPRESA</th>
                <th>SERVICIO</th>
                <th>AVANCE</th>
                <th>ESTADO</th>
                <th>PRIORIDAD</th>
                <th>FECHA</th>
            </tr>
        </thead>
       <tbody>


        </tbody>

    </table>

  </div>
</div>


<div class="modal fade" id="modalagregar" tabindex="-1" role="dialog" aria-labelledby="modalagregar" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Nuevo requerimiento</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">



 <form action="<?php echo e(route('requerimiento.store')); ?>" id="frmguardar" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

        <div class="form-group text-center">

            <img src="<?php echo e(asset('vendor/adminlte/dist/img/soporte.png')); ?>" alt=""  style="height: 200px; width: 200px;">
        </div>


        <div class="form-group">
            <label for="">TÍTULO:</label>

            <input type="hidden" name="usuarioregist_id" value="<?php echo e(auth()->user()->id); ?>" id="registro">

            <textarea maxlength="100" class="form-control" id="txtProblema" placeholder="Ingrese el nombre del requerimiento." rows="3" name="titulo"></textarea>

            <div id="contador">0/200</div>

        </div>


        <div class="form-row">

            <div class="form-group col-md-6">
                <label for="">EMPRESA RESPONSABLE</label>

                <select class="form-control" id="empresa" name="">
                    <option value="a" >Elegir</option>

                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($e->id); ?>"><?php echo e($e->nombre); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>


            </div>

            <div class="form-group col-md-6">
          <label for="">SERVICIO</label>

          <select class="form-control" id="servicio" name="empresa_servicio_id">
               <option value="a">¡Seleccione una empresa!</option>

            </select>

            </div>

          </div>

        <div class="form-row">


            <div class="form-group col-md-6">
          <label for="">GERENTE(S) RESPONSABLE(S)</label>

          <select style="width:100%" class="js-example-basic-multiple" id="gerente" name="usuarioencarg_id[]" multiple="multiple" lang="es">



            </select>

            </div>


            <div class="form-group col-md-6">
                <label for="">PRIORIDAD</label>

                <select class="form-control" id="" name="prioridad">
                    <option value="1">Elegir</option>

                    <option value="alta">ALTA</option>
                    <option value="media">MEDIA</option>
                    <option value="baja">BAJA</option>


                  </select>

            </div>

          </div>


 <div class="row">

        <div class="form-group col-md-6">


            <label for="">DESCRIPCIÓN:</label>

                <textarea maxlength="600" class="form-control" id="txtDetalle" placeholder="Ingrese el detalle del requerimiento." rows="10" name="descripcion"></textarea>

                <div id="contador2">0/600</div>

        </div>

        <div class="form-group col-md-6">

            <label for="">IMAGEN</label>

            <input type="file"  accept="image/*" class="img form-control-file" id="xy" name="imagenpost">

            <img id="prev" class="imagenPrevisualizacion mt-2" style="width: 350px;height: 200;">


            <button type="button" id="" class="retirar btn btn-info" style="display: none; border-radius: 0px;">QUITAR IMAGEN</button>

        </div>

</div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
        <button  id="btnguardar" class="btn btn-primary">GUARDAR</button>
      </div>
    </form>

    </div>
  </div>
</div>


<div class="modal fade" id="modaleditaravance" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Editar avance</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

            <form  id="frmeditaravance">

                <input type="hidden" class="form-control" id="idregistroavance"  name="id">

                <div class="form-row">

                    <div class="form-group col-md-12">

                        <label for="">Avance</label>
                        <input class="progress-bar progress-bar-striped progress-bar-animated" name="avance" type="range" id="editavance" min="0" value="0" max="100" step="5" style="width: 100%;">
                        <span id="editavan">0</span>
                    </div>



                  </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          <button type="" id="btnactualizaravance" class="btn btn-primary">Guardar</button>
        </div>

            </form>
      </div>
    </div>
  </div>


  <!-- Modal editar -->


<div class="modal fade" id="modaleditar" tabindex="-1" role="dialog" aria-labelledby="modaleditar" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel"><span class="div divoculto divocult">ACTUALIZA </span>REGISTRO DE MANTENIMIENTO</h5>

          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">

      <form  id="frmeditar" enctype="multipart/form-data">

        <input type="hidden" class="form-control" id="idregistro"  name="id">

        <div class="form-row" id="">

            <div class="divoculto divocult form-group text-center col-md-4">

                <input type="file"  accept="image/*" class="img form-control-file" id="imn" name="imagennue">

                <img id="imag" onerror="this.style.display='none'" class="imagenPrevisualizacion mt-2" style="width: 200px;height: 200px;display: none;">

            </div>



            <div class="form-group text-center row justify-content-center align-items-end col-md-4">

                   <img src="<?php echo e(asset('vendor/adminlte/dist/img/req.png')); ?>" alt="" id="mostimg" style="height: 200px; width: 200px;" name="">

                </div>


            <div class="form-group text-center row justify-content-center align-items-center col-md-4">

                <button type="button" id="consim" class="retirar btn btn-info" style="display: none;">CONSERVAR IMAGEN</button>

            </div>

        </div>


        <div class="form-row">

            <div class="form-group col-md-12">
                <label for="">USUARIO SOLICITANTE:</label>
                <input type="hidden" class="form-control" name="usuarioregist_id" id="UsuarioSolicitante2" readonly>
                <input class="form-control"  type="text" value=""  id="UsuarioSolicitante" readonly>

            </div>

            <div class="form-group col-md-12">
                <label for="">GERENTE(S) RESPONSABLE(S)</label>
            <input class="form-control"  type="text" name="" id="UsuarioResponsable" readonly>

            </div>


          </div>

        <div class="form-row">

            <div class="form-group col-md-12">
                <label for="">TÍTULO:</label>

                <textarea maxlength="100" readonly class="datosocultos form-control" id="editarTitulo" placeholder="Ingrese el nombre del requerimiento." rows="2" name="titulo"></textarea>
            </div>


          </div>


        <div class="form-row">

            <div class="form-group col-md-12">

                <label for="">DESCRIPCIÓN:</label>
                <textarea maxlength="200" readonly class="datosocultos form-control" id="editarDescripcion" placeholder="Ingrese la descripción de la atención." rows="5" name="descripcion"></textarea>
            </div>


          </div>


            <div class="form-group" id="elemento">
                <label for="">AVANCE:</label>

            <div class="progress progress-md">
              <div class="progress-bar bg-primary progress-bar-striped progress-bar-animated" role="progressbar" id="avance" style="width: 100%" value="30" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <span id="avan">0</span>
                


            </div>



    <div class="divoculto divocult row">

        <div class="form-group col-md-6">
            <label for="">PRIORIDAD</label>

            <select class="form-control" id="prioridad" name="prioridad">


                <option value="alta">ALTA</option>
                <option value="media">MEDIA</option>
                <option value="baja">BAJA</option>

              </select>
        </div>

        <div class="form-group col-md-6">
            <label for="">ESTADO</label>

            <select class="form-control"  id="estado" name="estado">

                <option value="pendiente">PENDIENTE</option>
                <option value="en espera">EN ESPERA</option>
                <option value="en proceso">EN PROCESO</option>
                
              </select>
        </div>

    </div>

    <div class="divoculto divocu form-row">

        <div class="form-group col-md-12" id="trabajadores">

            <label for="">PERSONAL</label>
            <select style="width:100%" class="js-example-basic-multiple" id="personal" name="usuario_colab_id[]" multiple="multiple" readonly lang="es">

            </select>
        </div>

    </div>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
            <button type="" id="btnactualizar" class="btn btn-primary">EDITAR</button>
        </div>
      </form>

      </div>
    </div>
  </div>

  </div>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('js/requerimiento.js')); ?>"></script>

<script>

listar()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-compusistel\resources\views/requerimiento/index.blade.php ENDPATH**/ ?>