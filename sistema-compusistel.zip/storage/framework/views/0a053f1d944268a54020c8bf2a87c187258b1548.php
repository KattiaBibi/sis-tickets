<!-- <?php $__env->startSection('title', 'Dashboard'); ?> -->

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>


<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>

<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>
<div class="card">
  <div class="card-header">
  <h1 class="card-title">Special title treatment</h1>
  </div>
  <div class="card-body">
    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sis-tickets\resources\views/home.blade.php ENDPATH**/ ?>